package unistack.enums;

/**
 * @author Gyges Zean
 * @date 2018/3/12
 */
public enum FileEnums {
    MYSQL,
    ORACLE,
    POSTGRE
}
