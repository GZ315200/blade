
#!/bin/sh -x
cd `dirname $0`
source ../config/env.properties

JAVA_HOME=${java_home}

# Which java to use

java -classpath "../libs/generator-tools.jar" unistack.Main