
#!/bin/sh -x
cd `dirname $0`
echo ${PWD}
cd ${PWD}
source ../config/env.properties

JAVA_HOME=${java_home}
echo ${JAVA_HOME}
# Which java to use

${JAVA_HOME}/bin/java \ -classpath "../libs/generator-tools.jar" unistack.Main