#!/bin/bash


CURRENT_FOLDER=`dirname $0`
APPNAME=generatorData
echo $CURRENT_FOLDER
#APPVERSION=`date +%Y%m%d-%H%M%S`
echo "mvn clean package -Dmaven.test.skip=true"


mvn clean install -Dmaven.test.skip=true

cd target
mkdir generatorData
mkdir generatorData/libs
cp generator-tools.jar generatorData/libs
cp -r ../config/ generatorData/config
cp -r ../RELEASE_NOTES.md generatorData
cp -r ../scripts/ generatorData/scripts
cp -r ../db/ generatorData/db

if [ ! -d "${CURRENT_FOLDER}/${APPNAME}" ];then
mkdir "${CURRENT_FOLDER}/${APPNAME}"
fi
tar -zcvf generatorData.tar.gz generatorData
cp -r generatorData/ ${CURRENT_FOLDER}/${APPNAME}